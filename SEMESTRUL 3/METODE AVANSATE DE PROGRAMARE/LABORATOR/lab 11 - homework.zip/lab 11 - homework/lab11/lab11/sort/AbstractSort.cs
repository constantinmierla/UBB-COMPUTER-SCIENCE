﻿namespace lab11;

public abstract class AbstractSort<T>
{
    public abstract void Sort(T[] array);
}
