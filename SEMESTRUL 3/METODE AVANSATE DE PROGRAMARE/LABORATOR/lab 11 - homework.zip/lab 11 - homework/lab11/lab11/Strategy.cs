﻿namespace lab11;

public enum Strategy
{
    Lifo,
    Fifo,
    BubbleSort,
    QuickSort
}